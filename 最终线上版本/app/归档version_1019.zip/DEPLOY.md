# 部署手册（deskcupid.com）

> 给后续维护者 / agent：读完这一篇就能完成改代码 → 上线 → 回滚的全部操作。
> ⚠️ 本文件包含服务器密码，**不要提交到公开仓库**。推送 GitHub 前确认仓库是 private，或把本文件加进 .gitignore。

## 1. 服务器

| 项目 | 值 |
|---|---|
| IP | `119.28.26.250`（腾讯云轻量） |
| SSH 用户 | `ubuntu` |
| SSH 密码 | `DatIng_Honor7` |
| 应用目录 | `/opt/tongzhuo/app`（完整源码 + 构建产物都在这里） |
| 环境变量 | `/etc/tongzhuo/env`（systemd EnvironmentFile，见下） |
| Node | `/usr/bin/node` v22.23.2 |
| 运行方式 | systemd 服务 `tongzhuo`，`ExecStart=/usr/bin/node dist/boot.js`，User=root，崩溃自动重启 |
| 反向代理 | nginx（`/etc/nginx/sites-enabled/tongzhuo`），443 证书在服务器本地，转发到 node 的 PORT |
| 数据库 | 服务器本机 MySQL（systemd `mysql.service`，tongzhuo 依赖它），连接串在 env 的 `DATABASE_URL`（密码是 URL 编码的，取用时要解码） |

### 非交互 SSH（密码写在命令里，agent 必须用这种方式）

```bash
cat > /tmp/tz-askpass.sh <<'EOF'
#!/bin/bash
echo 'DatIng_Honor7'
EOF
chmod +x /tmp/tz-askpass.sh
export SSH_ASKPASS=/tmp/tz-askpass.sh SSH_ASKPASS_REQUIRE=force DISPLAY=:0

# 之后所有 ssh/scp/rsync 都不会再提示输密码：
ssh -o StrictHostKeyChecking=no ubuntu@119.28.26.250 'systemctl is-active tongzhuo'
```

注意：`SSH_ASKPASS_REQUIRE=force` 是关键，少了它 OpenSSH 不会读 askpass 脚本。`sudo` 在服务器上是免密的（`sudo -n` 可用）。

### `/etc/tongzhuo/env` 里的键（值不在本文档记录，到服务器上看）

```
NODE_ENV / PORT / APP_ID / APP_SECRET / DATABASE_URL / INVITE_CODE / ADMIN_PASSWORD
ALIYUN_ACCESS_KEY_ID / ALIYUN_ACCESS_KEY_SECRET / SMS_SIGN_NAME / SMS_OTP_TEMPLATE   # 短信（尚未启用）
WECOM_CORPID / WECOM_KF_SECRET / WECOM_KF_OPENID / WECOM_TOKEN / WECOM_AES_KEY        # 企业微信客服
LLM_API_KEY / LLM_BASE_URL / LLM_MODEL                                               # DeepSeek
FIELD_ENCRYPTION_KEY                                                                 # 字段级加密
```

改 env 后必须 `sudo systemctl restart tongzhuo` 才生效。

## 2. Git

- GitHub：`git@github.com:ZhengyuLi0929/PlumTree.git`，工作分支 **`0913event`**（不是 main）
- 本地代码：`/Users/apple/Desktop/The Dating Project/最终线上版本/app`
- 版本约定：每次上线打「存档点N / vX.Y.Z」格式的 commit，例如 `存档点23 / v6.0.0: ...`（`git log --oneline` 可见全部存档点）

## 3. 标准上线流程

```bash
cd "/Users/apple/Desktop/The Dating Project/最终线上版本/app"

# 1) 本地验证：类型检查 + 构建（构建产物 = dist/ 静态文件 + dist/boot.js 单文件后端，依赖已全部打进 bundle）
npm run check && npm run build

# 2) 测试（按需）：npm run test:all（106 个）/ test:member / test:matching / test:bot / test:dsmatch

# 3) 打 tar 包上传（rsync 到这台服务器实测会中途断连，不要用 rsync；用 tar+scp）
export SSH_ASKPASS=/tmp/tz-askpass.sh SSH_ASKPASS_REQUIRE=force DISPLAY=:0
COPYFILE_DISABLE=1 tar czf /tmp/tz-app.tgz --exclude node_modules --exclude dist --exclude .git --exclude .env .
scp -o StrictHostKeyChecking=no /tmp/tz-app.tgz ubuntu@119.28.26.250:/tmp/tz-app.tgz

# 4) 服务器上解压 + 装依赖 + 构建 + 重启（注意：app 目录属 root，必须全程 sudo；
#    解压时的 "Ignoring unknown extended header" 警告是 macOS xattr 噪音，无害）
ssh -o StrictHostKeyChecking=no ubuntu@119.28.26.250 \
  'cd /opt/tongzhuo/app && sudo tar xzf /tmp/tz-app.tgz && rm /tmp/tz-app.tgz && \
   sudo bash -c "set -e; cd /opt/tongzhuo/app && npm install --no-audit --no-fund && npm run build && systemctl restart tongzhuo && sleep 2 && systemctl is-active tongzhuo"'

# 5) 验证（首页 200 + API 有返回 + 新文案进了线上 bundle）
curl -s -o /dev/null -w "%{http_code}\n" https://deskcupid.com/
curl -s "https://deskcupid.com/api/trpc/responses.memberMe?input=%7B%22json%22%3A%7B%22preview%22%3Atrue%7D%7D" | head -c 200
```

- 服务器上跑 `npm install`/`npm run build` 必须 `sudo bash -c "..."`：目录属 root，且管道会掩盖失败（`| tail` 吃掉了退出码），不 set -e 就会出现"构建失败但服务照旧重启"的假成功。
- `dist/boot.js` 是 esbuild 全量 bundle，运行时不依赖 node_modules；但 `npm run build` 需要 devDependencies，所以服务器上要跑完整 `npm install`。
- 数据库表结构变更不需要手动迁移：`ensureTable()` 在服务启动/首次请求时自动建表加列。
- 只改了前端也可以走同一流程，没有单独的"前端部署"。

## 4. 回滚

```bash
# 本地回退到某个存档点（先 git log --oneline 找），再按上面流程重新部署
git log --oneline
git checkout 6fcbac2 -- .        # 例：回到存档点23 的文件内容（或 git revert 指定提交）
npm run check && npm run build   # 然后 rsync + 服务器 build + restart
```

数据库不在 git 里。涉及表数据的操作（去重、迁移）都有对应脚本在 `scripts/`（如 `rehash-passwords.ts`），回滚代码前想清楚数据是否兼容。

## 5. 排障

```bash
# 服务日志（线上排错第一入口）
ssh ... 'sudo journalctl -u tongzhuo -n 200 --no-pager'
# 实时跟随
ssh ... 'sudo journalctl -u tongzhuo -f'
# nginx 日志
ssh ... 'sudo tail -100 /var/log/nginx/error.log'
# 服务状态三连
ssh ... 'systemctl is-active tongzhuo mysql nginx'
```

## 6. 本地开发环境

| 项目 | 值 |
|---|---|
| 代码 | `/Users/apple/Desktop/The Dating Project/最终线上版本/app` |
| dev 服务器 | `npm run dev -- --port 3100`（前后端同端口，vite 中间件挂 API） |
| 本地数据库 | docker 容器 `app-mysql-1`，`127.0.0.1:3307`，库/用户/密码都是 `tongzhuo`，连接串在 `.env` 的 `DATABASE_URL` |
| 预览页（免登录假数据） | `/me?preview=142857`（线上也可看，只读） |
| 灰度开关 | `/me?beta=1` 开启「本周同桌的TA」tab（存 sessionStorage），`?beta=0` 关闭 |
| 后台 | `/admin`，密码 `HonorClass7`（线上同） |

## 7. 上线纪律（和用户约定好的）

1. 灰度功能先给灰度链接（`?beta=1` / `?preview=142857`），确认后再全量。
2. 部署前必须本地 `npm run check && npm run build` 干净；涉及匹配/会员流程的改动跑对应测试脚本。
3. 部署后必须 curl 验证线上 200 + 关键接口有返回。
4. 每次上线 = 一个存档点 commit 并 push 到 `0913event`。
5. 种子用户密码 CSV（`种子用户初始密码_2026-10-12.csv`，项目根目录）已 gitignore，**永远不提交**。
